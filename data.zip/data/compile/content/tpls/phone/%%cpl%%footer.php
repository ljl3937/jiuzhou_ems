<footer class="container-fluid text-center" style="background-color:#337AB7;">
	<p style="padding:1rem;">
		PHPEMS模拟考试系统 著作权登记号：2013 SR 113189<br />
		Copyright © phpems.net 2015-2017
	</p>
</footer>