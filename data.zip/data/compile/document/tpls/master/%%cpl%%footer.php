<div class="container-fluid box" style="background-color:#337AB7;margin-bottom:0px;" id="footer">
	<div class="row-fluid">
		<div class="main itembox">
			<div class="col-xs-12">
				<ul class="list-unstyled">
					<li class="text-center"><a href="">PHPEMS在线模拟考试系统 著作权登记号：2013 SR 113189</a></li>
					<li class="text-center"><a href="">Copyright © phpems.net  2015-2016</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>